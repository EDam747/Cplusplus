#include <iostream>
#include <fstream>
#include <map>
#include <string>
using namespace std;

class ItemTracker {
private:
	map<string, int> itemFrequencies; // Map that stores counts of item

	void loadData(const string& filename) { // Loads data from file to map
		ifstream inputFile(filename);
		string item;
		if (inputFile.is_open()) {
			while (inputFile >> item) {
				itemFrequencies[item]++;
			}
			inputFile.close();
		}
		else {
			cout << "Error: Unable to open file " << filename << endl;
		}
	}

	void saveData(const string& backupFile) {  // Saves Frequencies to a backup file
		ofstream outFile(backupFile);
		if (outFile.is_open()) {
			for (const auto& pair : itemFrequencies) {
				outFile << pair.first << " " << pair.second << endl; // write item and the count
			}
			outFile.close();
		}
		else {
			cout << "Error: Unable to write to file " << backupFile << endl;
		}
	}
public:
	// Constructor that starts tracker that loads data and saves backup
	ItemTracker(const string& filename, const string& backupFile) {
		loadData(filename);
		saveData(backupFile);
	}

	void searchItemFrequency() { // Function used to search for item and show frequency
		string item;
		cout << "Enter item name: ";
		cin >> item;
		cout << "Number of " << item << ": " << itemFrequencies[item] << endl;
	}

	void displayAllFrequencies() { // Command to display all item frequencies
		for (const auto& pair : itemFrequencies) {
			cout << pair.first << " " << pair.second << endl;
		}
	}

	void displayHistogram() { // Function to show a histogram of item and its frequencies
		for (const auto& pair : itemFrequencies) {
			cout << pair.first << " ";
			for (int i = 0; i < pair.second; i++) {
				cout << "*";
			}
			cout << endl; // Print asterisks equal to frequency
		}
	}
};

void displayMenu() { // Shows main menu options 1-4
	cout << "\nCorner Grocer Item Tracking System" << endl;
	cout << "1. Search for an item" << endl;
	cout << "2. Display all item frequencies" << endl;
	cout << "3. Display histogram" << endl;
	cout << "4. Exit" << endl;
	cout << "Pick from 1-4: ";
}

int main() { // creates the object ItemTracker  to keep data in order
	ItemTracker tracker("CS210_Project_Three_Input_File.txt", "frequency.dat");
	int choice;

	do {
		displayMenu(); // show menu
		cin >> choice;
		switch (choice) {
		case 1:
			tracker.searchItemFrequency(); // Search a specific items frequency
			break;
		case 2:
			tracker.displayAllFrequencies(); // show all item frequencies
			break;
		case 3:
			tracker.displayHistogram(); // Display histogram of item purchases
			break;
		case 4:
			cout << "Now Exiting program." << endl;
			break;
		default:
			cout << "Invalid selection. Please try again." << endl;
		
		}
	} while (choice != 4);

	return 0; // ends the program on command.

}